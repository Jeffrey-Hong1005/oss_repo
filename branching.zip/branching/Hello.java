public class Hello{
	
  public static void main(String[] args) {
	  
    System.out.println("Hello World");
	//using int function
	System.out.println("5 + 5 = ", sum(5,5));
	
  }
  
  private static int sum(int a, int b){
	  return a + b;
  }
	
  private static int substract(int a,  int b){
    
    //todo: finish function - from  junsoo
    return a - b;
  }
  
}